// import { Server } from "socket.io";

// let io: Server;

// export const initSocket = (server: any) => {
//   io = new Server(server, {
//     cors: {
//       origin: "http://localhost:3000",
//       methods: ["GET", "POST"],
//       credentials: true,
//     },
//   });

//   io.on("connection", (socket) => {
//     console.log("User connected:", socket.id);

//     socket.on("join", (userId) => {
//       socket.join(userId);
//     });
//   });
// };

// export const getIO = () => {
//   if (!io) {
//     throw new Error("Socket not initialized");
//   }
//   return io;
// };

import { Server } from "socket.io";

let io: Server;

export const initSocket = (server: any) => {
  io = new Server(server, {
    cors: {
      origin: ["http://localhost:3000", "http://192.168.1.17:3000"],
      methods: ["GET", "POST"],
    },
  });

  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join", (userId) => {
      if (!userId) return;
      socket.join(userId);
    });

    socket.on("send_message", (data: any) => {
      io.to(data.receiver).emit("receive_message", data);
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });
};

export const getIO = () => {
  if (!io) throw new Error("Socket not initialized");
  return io;
};