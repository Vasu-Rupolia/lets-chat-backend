import { Router } from "express";
import FriendRequest from "../models/FriendRequest";
import auth, { AuthRequest } from "../middlewares/auth";

const router = Router();


// 🔹 Send request
router.post("/request", auth, async (req: AuthRequest, res) => {
  const { userId } = req.body;

  const existing = await FriendRequest.findOne({
    from: req.user.id,
    to: userId,
  });

  if (existing) {
    return res.status(400).json({ message: "Already requested" });
  }

  const request = await FriendRequest.create({
    from: req.user.id,
    to: userId,
  });

  res.json(request);
});


// 🔹 Get pending requests (received)
router.get("/requests", auth, async (req: AuthRequest, res) => {
  const requests = await FriendRequest.find({
    to: req.user.id,
    status: "pending"
  }).populate("from", "name email");

  res.json(requests);
});


// 🔹 Accept request
router.post("/accept", auth, async (req: AuthRequest, res) => {
  const { requestId } = req.body;

  const request = await FriendRequest.findById(requestId);

  if (!request) return res.status(404).json({ message: "Not found" });

  request.status = "accepted";
  await request.save();

  res.json({ message: "Accepted" });
});


// 🔹 Reject request
router.post("/reject", auth, async (req: AuthRequest, res) => {
  const { requestId } = req.body;

  const request = await FriendRequest.findById(requestId);

  if (!request) return res.status(404).json({ message: "Not found" });

  request.status = "rejected";
  await request.save();

  res.json({ message: "Rejected" });
});


// 🔹 Friend list (IMPORTANT)
router.get("/list", auth, async (req: AuthRequest, res) => {
  const friends = await FriendRequest.find({
    $or: [
      { from: req.user.id },
      { to: req.user.id }
    ],
    status: "accepted"
  })
  .populate("from", "name email")
  .populate("to", "name email");

  res.json(friends);
});

export default router;